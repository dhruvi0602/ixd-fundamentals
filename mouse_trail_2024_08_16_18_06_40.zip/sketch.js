let trails = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  noStroke();
  
  
}

function draw() {
  background(240, 168, 192);

  trails.push(createVector(mouseX, mouseY));

  if (trails.length > 100) {
    trails.shift();
  }

  for (let i = 0; i < trails.length; i++) {
    let pos = trails[i];
    ellipse(pos.x, pos.y, i);
    fill(11, 66, 40, 44)
  }
}
